# Celebration Cake Shop — Full Stack Application

## Project Structure
```
ccs/
├── frontend/
│   └── index.html          ← Complete frontend (HTML/CSS/JS)
├── backend/
│   ├── src/
│   │   ├── main.ts
│   │   ├── app.module.ts
│   │   ├── auth/           ← Login, Register, OTP, JWT
│   │   ├── users/          ← User profile
│   │   ├── products/       ← Catalog, search, bestsellers
│   │   ├── orders/         ← Place order, track, history
│   │   ├── coupons/        ← Validate & manage coupons
│   │   └── delivery/       ← Agents & slots
│   ├── package.json
│   ├── tsconfig.json
│   └── .env.example
└── database/
    └── schema.sql          ← PostgreSQL schema + seed data
```

## Setup Instructions

### 1. Database (PostgreSQL)
```bash
sudo -u postgres psql
\i /path/to/database/schema.sql
```

### 2. Backend (NestJS)
```bash
cd backend
cp .env.example .env
# Edit .env with your DB credentials and JWT secret
npm install
npm run start:dev
# API runs on http://localhost:4000
# Swagger docs: http://localhost:4000/api/docs
```

### 3. Frontend
```bash
sudo mkdir -p /var/www/celebration-cake-shop/public
sudo cp frontend/index.html /var/www/celebration-cake-shop/public/index.html
```

### 4. Nginx
```bash
sudo cp nginx.conf /etc/nginx/nginx.conf
sudo cp proxy_params /etc/nginx/proxy_params
sudo nginx -t && sudo systemctl reload nginx
```

## API Endpoints

| Method | Route | Description |
|--------|-------|-------------|
| POST | /api/v1/auth/register | Register |
| POST | /api/v1/auth/login | Login → JWT |
| POST | /api/v1/auth/otp/send | Send OTP |
| POST | /api/v1/auth/otp/verify | Verify OTP |
| GET  | /api/v1/products | All products |
| GET  | /api/v1/products/bestsellers | Bestsellers |
| GET  | /api/v1/products/search?q= | Search |
| POST | /api/v1/orders | Place order |
| GET  | /api/v1/orders | My orders |
| GET  | /api/v1/orders/track/:id | Track order |
| POST | /api/v1/coupons/validate | Validate coupon |
| GET  | /api/v1/delivery/slots | Delivery slots |

## Default Credentials
- **Admin login:** admin@celebrationcakeshop.com / Admin@123
- **Coupons:** CELEBRATE20 · FREEDEL799 · BOGO2024

## Tech Stack
- **Frontend:** HTML5, CSS3, Vanilla JS
- **Backend:** Node.js, NestJS, TypeScript
- **Database:** PostgreSQL
- **Auth:** JWT + bcrypt
- **Server:** Nginx
