import { Injectable, UnauthorizedException, ConflictException, BadRequestException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { JwtService } from '@nestjs/jwt';
import * as bcrypt from 'bcrypt';
import { User } from '../users/user.entity';
import { LoginDto } from './dto/login.dto';
import { RegisterDto } from './dto/register.dto';

@Injectable()
export class AuthService {
  private otpStore = new Map<string, { otp: string; expiresAt: Date }>();

  constructor(
    @InjectRepository(User) private userRepo: Repository<User>,
    private jwtService: JwtService,
  ) {}

  async register(dto: RegisterDto) {
    const exists = await this.userRepo.findOne({ where: { email: dto.email } });
    if (exists) throw new ConflictException('Email already registered');
    const hashed = await bcrypt.hash(dto.password, 10);
    const user = this.userRepo.create({ ...dto, password: hashed });
    await this.userRepo.save(user);
    return { message: 'Registration successful', token: this.signToken(user), user: this.sanitize(user) };
  }

  async login(dto: LoginDto) {
    const user = await this.userRepo.findOne({ where: { email: dto.email }, select: ['id','name','email','mobile','role','isActive','password'] });
    if (!user) throw new UnauthorizedException('Invalid email or password');
    const valid = await bcrypt.compare(dto.password, user.password);
    if (!valid) throw new UnauthorizedException('Invalid email or password');
    if (!user.isActive) throw new UnauthorizedException('Account is deactivated');
    return { message: 'Login successful', token: this.signToken(user), user: this.sanitize(user) };
  }

  async sendOtp(mobile: string) {
    if (!mobile || mobile.length < 10) throw new BadRequestException('Invalid mobile number');
    const otp = Math.floor(100000 + Math.random() * 900000).toString();
    this.otpStore.set(mobile, { otp, expiresAt: new Date(Date.now() + 5 * 60 * 1000) });
    console.log(`[OTP] ${mobile}: ${otp}`); // replace with SMS provider in production
    return { message: 'OTP sent successfully', expiresIn: 300 };
  }

  async verifyOtp(mobile: string, otp: string) {
    const record = this.otpStore.get(mobile);
    if (!record) throw new BadRequestException('OTP not found, request a new one');
    if (new Date() > record.expiresAt) { this.otpStore.delete(mobile); throw new BadRequestException('OTP expired'); }
    if (record.otp !== otp) throw new BadRequestException('Invalid OTP');
    this.otpStore.delete(mobile);
    let user = await this.userRepo.findOne({ where: { mobile } });
    if (!user) { user = this.userRepo.create({ mobile, name: 'Guest', isActive: true }); await this.userRepo.save(user); }
    return { message: 'OTP verified', token: this.signToken(user), user: this.sanitize(user) };
  }

  private signToken(user: User) {
    return this.jwtService.sign({ sub: user.id, email: user.email, mobile: user.mobile, role: user.role });
  }

  private sanitize(user: User) {
    const { password, ...safe } = user as any;
    return safe;
  }
}
