import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn } from 'typeorm';

export enum CouponType { PERCENTAGE = 'percentage', FIXED = 'fixed', FREE_DELIVERY = 'free_delivery', BOGO = 'bogo' }

@Entity('coupons')
export class Coupon {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ unique: true })
  code: string;

  @Column({ type: 'enum', enum: CouponType })
  type: CouponType;

  @Column('decimal', { precision: 10, scale: 2, nullable: true })
  value: number;

  @Column('decimal', { precision: 10, scale: 2, default: 0 })
  minOrderAmount: number;

  @Column({ default: 0 })
  usedCount: number;

  @Column({ nullable: true })
  maxUses: number;

  @Column({ default: true })
  isActive: boolean;

  @Column({ nullable: true })
  expiresAt: Date;

  @CreateDateColumn()
  createdAt: Date;
}
