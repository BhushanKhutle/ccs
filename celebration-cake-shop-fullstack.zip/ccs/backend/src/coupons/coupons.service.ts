import { Injectable, NotFoundException, BadRequestException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Coupon, CouponType } from './coupon.entity';

@Injectable()
export class CouponsService {
  constructor(@InjectRepository(Coupon) private repo: Repository<Coupon>) {}

  findAll() { return this.repo.find(); }

  async validate(code: string, orderAmount: number) {
    const coupon = await this.repo.findOne({ where: { code: code.toUpperCase(), isActive: true } });
    if (!coupon) throw new NotFoundException('Invalid coupon code');
    if (coupon.expiresAt && new Date() > coupon.expiresAt) throw new BadRequestException('Coupon expired');
    if (coupon.maxUses && coupon.usedCount >= coupon.maxUses) throw new BadRequestException('Coupon usage limit reached');
    if (orderAmount < coupon.minOrderAmount) throw new BadRequestException(`Minimum order ₹${coupon.minOrderAmount} required`);

    let discount = 0;
    if (coupon.type === CouponType.PERCENTAGE) discount = (orderAmount * coupon.value) / 100;
    else if (coupon.type === CouponType.FIXED) discount = coupon.value;
    else if (coupon.type === CouponType.FREE_DELIVERY) discount = 0;

    return { valid: true, coupon, discount: Math.min(discount, orderAmount) };
  }

  create(data: Partial<Coupon>) { return this.repo.save(this.repo.create(data)); }
}
