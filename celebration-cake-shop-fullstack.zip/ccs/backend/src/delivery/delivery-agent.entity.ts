import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn } from 'typeorm';

@Entity('delivery_agents')
export class DeliveryAgent {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  name: string;

  @Column({ unique: true })
  mobile: string;

  @Column({ nullable: true })
  zone: string;

  @Column({ default: true })
  isActive: boolean;

  @Column({ default: 0 })
  todayOrders: number;

  @Column('decimal', { precision: 3, scale: 2, default: 0 })
  rating: number;

  @CreateDateColumn()
  createdAt: Date;
}
