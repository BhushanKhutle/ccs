import { Controller, Get, Post, Body, UseGuards } from '@nestjs/common';
import { ApiTags, ApiBearerAuth } from '@nestjs/swagger';
import { DeliveryService } from './delivery.service';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';

@ApiTags('Delivery')
@Controller('api/v1/delivery')
export class DeliveryController {
  constructor(private readonly deliveryService: DeliveryService) {}

  @Get('slots')
  getSlots() { return this.deliveryService.getSlots(); }

  @Get('agents')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  getAgents() { return this.deliveryService.findAll(); }

  @Post('agents')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  createAgent(@Body() body) { return this.deliveryService.create(body); }
}
