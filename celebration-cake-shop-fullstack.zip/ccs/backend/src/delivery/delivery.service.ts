import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { DeliveryAgent } from './delivery-agent.entity';

@Injectable()
export class DeliveryService {
  constructor(@InjectRepository(DeliveryAgent) private repo: Repository<DeliveryAgent>) {}

  findAll() { return this.repo.find({ where: { isActive: true } }); }
  create(data: Partial<DeliveryAgent>) { return this.repo.save(this.repo.create(data)); }

  getSlots() {
    return [
      { id: 1, label: '6 AM – 10 AM',   charge: 0,   available: true },
      { id: 2, label: '10 AM – 2 PM',   charge: 0,   available: true },
      { id: 3, label: '2 PM – 6 PM',    charge: 0,   available: true },
      { id: 4, label: '6 PM – 9 PM',    charge: 49,  available: true },
      { id: 5, label: '9 PM – 12 AM',   charge: 99,  available: true },
      { id: 6, label: 'Fixed Time',      charge: 149, available: true },
    ];
  }
}
