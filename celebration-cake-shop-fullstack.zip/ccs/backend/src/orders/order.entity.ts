import { Entity, PrimaryGeneratedColumn, Column, ManyToOne, OneToMany, CreateDateColumn, UpdateDateColumn } from 'typeorm';
import { User } from '../users/user.entity';

export enum OrderStatus {
  PLACED = 'placed', CONFIRMED = 'confirmed', PREPARING = 'preparing',
  OUT_FOR_DELIVERY = 'out_for_delivery', DELIVERED = 'delivered', CANCELLED = 'cancelled',
}

@Entity('orders')
export class Order {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ unique: true })
  orderNumber: string;

  @ManyToOne(() => User)
  user: User;

  @Column({ type: 'jsonb' })
  items: any[];

  @Column({ type: 'jsonb', nullable: true })
  address: any;

  @Column('decimal', { precision: 10, scale: 2 })
  subtotal: number;

  @Column('decimal', { precision: 10, scale: 2, default: 0 })
  discount: number;

  @Column('decimal', { precision: 10, scale: 2, default: 0 })
  deliveryCharge: number;

  @Column('decimal', { precision: 10, scale: 2 })
  total: number;

  @Column({ nullable: true })
  couponCode: string;

  @Column({ nullable: true })
  paymentMethod: string;

  @Column({ nullable: true })
  paymentStatus: string;

  @Column({ type: 'enum', enum: OrderStatus, default: OrderStatus.PLACED })
  status: OrderStatus;

  @Column({ nullable: true })
  deliverySlot: string;

  @Column({ nullable: true })
  deliveryDate: string;

  @Column({ nullable: true })
  message: string;

  @Column({ nullable: true })
  agentName: string;

  @Column({ nullable: true })
  agentMobile: string;

  @Column({ nullable: true })
  otp: string;

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;
}
