import { Controller, Get, Post, Patch, Body, Param, UseGuards, Request } from '@nestjs/common';
import { ApiTags, ApiOperation, ApiBearerAuth } from '@nestjs/swagger';
import { OrdersService } from './orders.service';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';

@ApiTags('Orders')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller('api/v1/orders')
export class OrdersController {
  constructor(private readonly ordersService: OrdersService) {}

  @Post()
  @ApiOperation({ summary: 'Place a new order' })
  create(@Request() req, @Body() body) { return this.ordersService.create(req.user.id, body); }

  @Get()
  @ApiOperation({ summary: 'Get my orders' })
  myOrders(@Request() req) { return this.ordersService.findByUser(req.user.id); }

  @Get('track/:orderNumber')
  @ApiOperation({ summary: 'Track order by order number' })
  track(@Param('orderNumber') orderNumber: string) { return this.ordersService.findByNumber(orderNumber); }

  @Get(':id')
  findOne(@Param('id') id: string) { return this.ordersService.findOne(+id); }

  @Patch(':id/status')
  @ApiOperation({ summary: 'Update order status (admin)' })
  updateStatus(@Param('id') id: string, @Body('status') status: any) {
    return this.ordersService.updateStatus(+id, status);
  }
}
