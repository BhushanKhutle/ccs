import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Order, OrderStatus } from './order.entity';

@Injectable()
export class OrdersService {
  constructor(@InjectRepository(Order) private repo: Repository<Order>) {}

  async create(userId: number, data: any) {
    const orderNumber = `CCS-${Date.now()}`;
    const otp = Math.floor(1000 + Math.random() * 9000).toString();
    const order = this.repo.create({
      ...data,
      orderNumber,
      otp,
      user: { id: userId },
      status: OrderStatus.PLACED,
      paymentStatus: 'pending',
    });
    return this.repo.save(order);
  }

  findByUser(userId: number) {
    return this.repo.find({ where: { user: { id: userId } }, order: { createdAt: 'DESC' } });
  }

  findAll() { return this.repo.find({ order: { createdAt: 'DESC' } }); }

  async findOne(id: number) {
    const order = await this.repo.findOne({ where: { id }, relations: ['user'] });
    if (!order) throw new NotFoundException('Order not found');
    return order;
  }

  async findByNumber(orderNumber: string) {
    const order = await this.repo.findOne({ where: { orderNumber } });
    if (!order) throw new NotFoundException('Order not found');
    return order;
  }

  async updateStatus(id: number, status: OrderStatus) {
    await this.repo.update(id, { status });
    return this.findOne(id);
  }
}
