import { Controller, Get, Post, Put, Delete, Body, Param, Query, UseGuards } from '@nestjs/common';
import { ApiTags, ApiOperation, ApiBearerAuth, ApiQuery } from '@nestjs/swagger';
import { ProductsService } from './products.service';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';

@ApiTags('Products')
@Controller('api/v1/products')
export class ProductsController {
  constructor(private readonly productsService: ProductsService) {}

  @Get()
  @ApiOperation({ summary: 'Get all products' })
  @ApiQuery({ name: 'category', required: false })
  @ApiQuery({ name: 'occasion', required: false })
  @ApiQuery({ name: 'eggless', required: false })
  findAll(@Query() query) { return this.productsService.findAll(query); }

  @Get('bestsellers')
  @ApiOperation({ summary: 'Get bestseller products' })
  getBestsellers() { return this.productsService.getBestsellers(); }

  @Get('search')
  @ApiOperation({ summary: 'Search products' })
  search(@Query('q') q: string) { return this.productsService.search(q); }

  @Get(':id')
  findOne(@Param('id') id: string) { return this.productsService.findOne(+id); }

  @Post()
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  create(@Body() body) { return this.productsService.create(body); }

  @Put(':id')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  update(@Param('id') id: string, @Body() body) { return this.productsService.update(+id, body); }

  @Delete(':id')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  remove(@Param('id') id: string) { return this.productsService.remove(+id); }
}
