import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, Like, FindManyOptions } from 'typeorm';
import { Product } from './product.entity';

@Injectable()
export class ProductsService {
  constructor(@InjectRepository(Product) private repo: Repository<Product>) {}

  findAll(query: any = {}) {
    const where: any = { isActive: true };
    if (query.category) where.category = query.category;
    if (query.occasion) where.occasion = query.occasion;
    if (query.eggless !== undefined) where.eggless = query.eggless === 'true';
    return this.repo.find({ where, order: { createdAt: 'DESC' } });
  }

  search(q: string) {
    return this.repo.find({
      where: [{ name: Like(`%${q}%`), isActive: true }, { category: Like(`%${q}%`), isActive: true }],
    });
  }

  async findOne(id: number) {
    const p = await this.repo.findOne({ where: { id } });
    if (!p) throw new NotFoundException('Product not found');
    return p;
  }

  create(data: Partial<Product>) { return this.repo.save(this.repo.create(data)); }

  async update(id: number, data: Partial<Product>) {
    await this.repo.update(id, data);
    return this.findOne(id);
  }

  remove(id: number) { return this.repo.delete(id); }

  getBestsellers() { return this.repo.find({ where: { isActive: true }, order: { rating: 'DESC' }, take: 12 }); }
}
