-- ══════════════════════════════════════════════════════════════
--  Celebration Cake Shop — PostgreSQL Schema
-- ══════════════════════════════════════════════════════════════

CREATE DATABASE celebration_cake_shop;
\c celebration_cake_shop;

-- Users
CREATE TYPE user_role AS ENUM ('customer', 'admin', 'agent');
CREATE TABLE users (
  id             SERIAL PRIMARY KEY,
  name           VARCHAR(100),
  email          VARCHAR(150) UNIQUE,
  mobile         VARCHAR(15) UNIQUE,
  password       VARCHAR(255),
  role           user_role DEFAULT 'customer',
  wallet_balance DECIMAL(10,2) DEFAULT 0,
  is_active      BOOLEAN DEFAULT TRUE,
  created_at     TIMESTAMP DEFAULT NOW(),
  updated_at     TIMESTAMP DEFAULT NOW()
);

-- Products
CREATE TABLE products (
  id           SERIAL PRIMARY KEY,
  name         VARCHAR(200) NOT NULL,
  description  TEXT,
  price        DECIMAL(10,2) NOT NULL,
  old_price    DECIMAL(10,2),
  category     VARCHAR(100),
  occasion     VARCHAR(100),
  flavour      VARCHAR(100),
  emoji        VARCHAR(10),
  image_url    VARCHAR(500),
  weights      TEXT,
  flavours     TEXT,
  eggless      BOOLEAN DEFAULT TRUE,
  is_active    BOOLEAN DEFAULT TRUE,
  stock        INT DEFAULT 100,
  rating       DECIMAL(3,2) DEFAULT 0,
  review_count INT DEFAULT 0,
  tag          VARCHAR(50),
  created_at   TIMESTAMP DEFAULT NOW(),
  updated_at   TIMESTAMP DEFAULT NOW()
);

-- Orders
CREATE TYPE order_status AS ENUM ('placed','confirmed','preparing','out_for_delivery','delivered','cancelled');
CREATE TABLE orders (
  id              SERIAL PRIMARY KEY,
  order_number    VARCHAR(50) UNIQUE NOT NULL,
  user_id         INT REFERENCES users(id),
  items           JSONB NOT NULL,
  address         JSONB,
  subtotal        DECIMAL(10,2) NOT NULL,
  discount        DECIMAL(10,2) DEFAULT 0,
  delivery_charge DECIMAL(10,2) DEFAULT 0,
  total           DECIMAL(10,2) NOT NULL,
  coupon_code     VARCHAR(50),
  payment_method  VARCHAR(50),
  payment_status  VARCHAR(50) DEFAULT 'pending',
  status          order_status DEFAULT 'placed',
  delivery_slot   VARCHAR(100),
  delivery_date   VARCHAR(30),
  message         VARCHAR(255),
  agent_name      VARCHAR(100),
  agent_mobile    VARCHAR(15),
  otp             VARCHAR(6),
  created_at      TIMESTAMP DEFAULT NOW(),
  updated_at      TIMESTAMP DEFAULT NOW()
);

-- Coupons
CREATE TYPE coupon_type AS ENUM ('percentage','fixed','free_delivery','bogo');
CREATE TABLE coupons (
  id               SERIAL PRIMARY KEY,
  code             VARCHAR(50) UNIQUE NOT NULL,
  type             coupon_type NOT NULL,
  value            DECIMAL(10,2),
  min_order_amount DECIMAL(10,2) DEFAULT 0,
  used_count       INT DEFAULT 0,
  max_uses         INT,
  is_active        BOOLEAN DEFAULT TRUE,
  expires_at       TIMESTAMP,
  created_at       TIMESTAMP DEFAULT NOW()
);

-- Delivery agents
CREATE TABLE delivery_agents (
  id           SERIAL PRIMARY KEY,
  name         VARCHAR(100) NOT NULL,
  mobile       VARCHAR(15) UNIQUE NOT NULL,
  zone         VARCHAR(100),
  is_active    BOOLEAN DEFAULT TRUE,
  today_orders INT DEFAULT 0,
  rating       DECIMAL(3,2) DEFAULT 0,
  created_at   TIMESTAMP DEFAULT NOW()
);

-- Reviews
CREATE TABLE reviews (
  id         SERIAL PRIMARY KEY,
  user_id    INT REFERENCES users(id),
  product_id INT REFERENCES products(id),
  order_id   INT REFERENCES orders(id),
  rating     INT CHECK (rating BETWEEN 1 AND 5),
  comment    TEXT,
  created_at TIMESTAMP DEFAULT NOW()
);

-- Addresses
CREATE TABLE addresses (
  id          SERIAL PRIMARY KEY,
  user_id     INT REFERENCES users(id),
  label       VARCHAR(50),
  name        VARCHAR(100),
  mobile      VARCHAR(15),
  line1       VARCHAR(255),
  line2       VARCHAR(255),
  city        VARCHAR(100),
  state       VARCHAR(100),
  pincode     VARCHAR(10),
  is_default  BOOLEAN DEFAULT FALSE,
  created_at  TIMESTAMP DEFAULT NOW()
);

-- Wishlists
CREATE TABLE wishlists (
  id         SERIAL PRIMARY KEY,
  user_id    INT REFERENCES users(id),
  product_id INT REFERENCES products(id),
  created_at TIMESTAMP DEFAULT NOW(),
  UNIQUE(user_id, product_id)
);

-- ── Seed: default coupons ─────────────────────────────────────
INSERT INTO coupons (code, type, value, min_order_amount, max_uses) VALUES
  ('CELEBRATE20', 'percentage',    20, 499,  NULL),
  ('FREEDEL799',  'free_delivery',  0, 799,  NULL),
  ('BOGO2024',    'bogo',           0, 349,  500);

-- ── Seed: sample products ─────────────────────────────────────
INSERT INTO products (name, description, price, category, occasion, flavour, emoji, eggless, tag, rating, review_count, stock) VALUES
  ('Rich Chocolate Truffle Cake','Velvety chocolate truffle with dark ganache',549,'Chocolate','Birthday','Chocolate','🎂',TRUE,'Bestseller',4.9,8500,100),
  ('Blueberry Cheesecake','NY-style on buttery biscuit base',779,'Cheesecake','Anniversary','Blueberry','🍰',FALSE,'New',4.9,801,50),
  ('Classic Black Forest Cake','Chocolate sponge, cream and cherries',549,'Chocolate','Birthday','Chocolate','🎂',TRUE,NULL,4.9,1000,80),
  ('Butterscotch Crunch Cake','Caramel cream with praline crunch',529,'Butterscotch','Birthday','Butterscotch','🎂',TRUE,'New',5.0,5,60),
  ('Unicorn Designer Cake','Rainbow sponge with candy horn',1249,'Designer','Birthday','Vanilla','🦄',TRUE,'Popular',4.9,3200,30),
  ('Red Velvet Anniversary Cake','Cream cheese frosting on red velvet',699,'Red Velvet','Anniversary','Red Velvet','❤️',FALSE,'Sale',4.8,4100,70),
  ('Rasmalai Pistachio Cake','Rasmalai sponge with rose petals',699,'Fusion','Wedding','Rasmalai','🍮',TRUE,'Sale',4.8,579,40),
  ('Mango Delight Bento Cake','Alphonso mango mousse bento',399,'Bento','Birthday','Mango','🥭',TRUE,'Trending',4.7,824,90);

-- ── Seed: admin user (password: Admin@123) ────────────────────
INSERT INTO users (name, email, mobile, password, role) VALUES
  ('Admin', 'admin@celebrationcakeshop.com', '9000000000',
   '$2b$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin');
