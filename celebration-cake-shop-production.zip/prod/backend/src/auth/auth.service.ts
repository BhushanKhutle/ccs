import {
  Injectable, UnauthorizedException, ConflictException,
  BadRequestException, Logger,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { JwtService } from '@nestjs/jwt';
import { ConfigService } from '@nestjs/config';
import * as bcrypt from 'bcrypt';
import { User } from '../users/user.entity';
import { LoginDto } from './dto/login.dto';
import { RegisterDto } from './dto/register.dto';

interface OtpRecord { otp: string; expiresAt: Date; attempts: number; }

@Injectable()
export class AuthService {
  private readonly logger = new Logger(AuthService.name);
  private readonly otpStore = new Map<string, OtpRecord>();
  private readonly bcryptRounds: number;

  constructor(
    @InjectRepository(User) private userRepo: Repository<User>,
    private jwtService: JwtService,
    private configService: ConfigService,
  ) {
    this.bcryptRounds = +configService.get('BCRYPT_ROUNDS', 12);
  }

  async register(dto: RegisterDto) {
    const existing = await this.userRepo.findOne({
      where: [{ email: dto.email }, { mobile: dto.mobile }],
    });
    if (existing) {
      if (existing.email === dto.email) throw new ConflictException('Email already registered');
      throw new ConflictException('Mobile number already registered');
    }

    const hashedPassword = await bcrypt.hash(dto.password, this.bcryptRounds);
    const user = this.userRepo.create({
      name: dto.name,
      email: dto.email.toLowerCase(),
      mobile: dto.mobile,
      password: hashedPassword,
    });
    const saved = await this.userRepo.save(user);
    this.logger.log(`New user registered: ${saved.email}`);

    const token = this.signToken(saved);
    return { message: 'Registration successful', token, user: this.sanitize(saved) };
  }

  async login(dto: LoginDto) {
    const user = await this.userRepo.findOne({
      where: { email: dto.email.toLowerCase() },
      select: ['id','name','email','mobile','role','isActive','walletBalance','password'],
    });

    if (!user || !(await bcrypt.compare(dto.password, user.password))) {
      throw new UnauthorizedException('Invalid email or password');
    }

    if (!user.isActive) {
      throw new UnauthorizedException('Your account has been deactivated. Please contact support.');
    }

    await this.userRepo.update(user.id, { lastLoginAt: new Date() });

    const token = this.signToken(user);
    return { message: 'Login successful', token, user: this.sanitize(user) };
  }

  async sendOtp(mobile: string) {
    if (!/^[6-9]\d{9}$/.test(mobile)) throw new BadRequestException('Invalid mobile number');

    const existing = this.otpStore.get(mobile);
    if (existing && existing.expiresAt > new Date() && existing.attempts < 3) {
      return { message: 'OTP already sent', expiresIn: 300 };
    }

    const otp = Math.floor(100000 + Math.random() * 900000).toString();
    this.otpStore.set(mobile, { otp, expiresAt: new Date(Date.now() + 5 * 60 * 1000), attempts: 0 });

    // TODO: integrate SMS provider (MSG91 / Twilio)
    this.logger.log(`OTP for ${mobile}: ${otp} (integrate SMS in production)`);

    return { message: 'OTP sent successfully', expiresIn: 300 };
  }

  async verifyOtp(mobile: string, otp: string) {
    const record = this.otpStore.get(mobile);
    if (!record) throw new BadRequestException('OTP not found. Please request a new OTP.');
    if (new Date() > record.expiresAt) { this.otpStore.delete(mobile); throw new BadRequestException('OTP has expired'); }

    record.attempts++;
    if (record.attempts > 3) { this.otpStore.delete(mobile); throw new BadRequestException('Too many attempts. Request a new OTP.'); }
    if (record.otp !== otp) throw new BadRequestException(`Invalid OTP. ${3 - record.attempts} attempts remaining.`);

    this.otpStore.delete(mobile);

    let user = await this.userRepo.findOne({ where: { mobile } });
    if (!user) {
      user = this.userRepo.create({ mobile, name: 'Guest User', isActive: true });
      await this.userRepo.save(user);
    }

    const token = this.signToken(user);
    return { message: 'OTP verified successfully', token, user: this.sanitize(user) };
  }

  private signToken(user: User): string {
    return this.jwtService.sign({
      sub: user.id, email: user.email,
      mobile: user.mobile, role: user.role,
    });
  }

  private sanitize(user: User) {
    const { password, ...safe } = user as any;
    return safe;
  }
}
