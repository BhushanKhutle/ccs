import { Entity, PrimaryGeneratedColumn, Column, ManyToOne, CreateDateColumn, UpdateDateColumn, Index, JoinColumn } from 'typeorm';
import { User } from '../users/user.entity';

export enum OrderStatus {
  PLACED = 'placed', CONFIRMED = 'confirmed', PREPARING = 'preparing',
  OUT_FOR_DELIVERY = 'out_for_delivery', DELIVERED = 'delivered', CANCELLED = 'cancelled',
}

export enum PaymentStatus { PENDING = 'pending', PAID = 'paid', FAILED = 'failed', REFUNDED = 'refunded' }

@Entity('orders')
export class Order {
  @PrimaryGeneratedColumn()
  id: number;

  @Index({ unique: true })
  @Column()
  orderNumber: string;

  @ManyToOne(() => User, { nullable: true })
  @JoinColumn({ name: 'userId' })
  user: User;

  @Column({ nullable: true })
  userId: number;

  @Column({ type: 'jsonb' })
  items: any[];

  @Column({ type: 'jsonb', nullable: true })
  address: any;

  @Column({ type: 'decimal', precision: 10, scale: 2 })
  subtotal: number;

  @Column({ type: 'decimal', precision: 10, scale: 2, default: 0 })
  discount: number;

  @Column({ type: 'decimal', precision: 10, scale: 2, default: 0 })
  deliveryCharge: number;

  @Column({ type: 'decimal', precision: 10, scale: 2 })
  total: number;

  @Column({ nullable: true })
  couponCode: string;

  @Column({ nullable: true })
  paymentMethod: string;

  @Column({ type: 'enum', enum: PaymentStatus, default: PaymentStatus.PENDING })
  paymentStatus: PaymentStatus;

  @Index()
  @Column({ type: 'enum', enum: OrderStatus, default: OrderStatus.PLACED })
  status: OrderStatus;

  @Column({ nullable: true })
  deliverySlot: string;

  @Column({ nullable: true })
  deliveryDate: string;

  @Column({ nullable: true })
  message: string;

  @Column({ nullable: true })
  agentId: number;

  @Column({ nullable: true })
  agentName: string;

  @Column({ nullable: true })
  otp: string;

  @Column({ type: 'text', nullable: true })
  cancellationReason: string;

  @Column({ type: 'jsonb', nullable: true, default: [] })
  statusHistory: any[];

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;
}
