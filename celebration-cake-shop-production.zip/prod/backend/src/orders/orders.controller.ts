import { Controller, Get, Post, Patch, Delete, Body, Param, ParseIntPipe, Query, UseGuards, Request } from '@nestjs/common';
import { ApiTags, ApiOperation, ApiBearerAuth, ApiQuery } from '@nestjs/swagger';
import { OrdersService } from './orders.service';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { OrderStatus } from './order.entity';

@ApiTags('Orders')
@ApiBearerAuth('JWT')
@UseGuards(JwtAuthGuard)
@Controller('api/v1/orders')
export class OrdersController {
  constructor(private readonly svc: OrdersService) {}

  @Post()
  @ApiOperation({ summary: 'Place a new order' })
  create(@Request() req, @Body() body: any) { return this.svc.create(req.user.id, body); }

  @Get()
  @ApiOperation({ summary: 'Get my orders' })
  @ApiQuery({ name: 'page', required: false })
  @ApiQuery({ name: 'limit', required: false })
  myOrders(@Request() req, @Query('page') page=1, @Query('limit') limit=10) {
    return this.svc.findByUser(req.user.id, +page, +limit);
  }

  @Get('all')
  @ApiOperation({ summary: 'Get all orders (admin)' })
  @ApiQuery({ name: 'page', required: false })
  @ApiQuery({ name: 'status', required: false })
  allOrders(@Query('page') page=1, @Query('limit') limit=20, @Query('status') status?: OrderStatus) {
    return this.svc.findAll(+page, +limit, status);
  }

  @Get('stats')
  @ApiOperation({ summary: 'Order statistics (admin)' })
  stats() { return this.svc.getStats(); }

  @Get('track/:orderNumber')
  @ApiOperation({ summary: 'Track order by order number (public)' })
  track(@Param('orderNumber') orderNumber: string) { return this.svc.findByNumber(orderNumber); }

  @Get(':id')
  @ApiOperation({ summary: 'Get order by ID' })
  findOne(@Param('id', ParseIntPipe) id: number) { return this.svc.findOne(id); }

  @Patch(':id/status')
  @ApiOperation({ summary: 'Update order status (admin)' })
  updateStatus(@Param('id', ParseIntPipe) id: number, @Body('status') status: OrderStatus, @Body('note') note: string) {
    return this.svc.updateStatus(id, status, note);
  }

  @Post(':id/cancel')
  @ApiOperation({ summary: 'Cancel order' })
  cancel(@Param('id', ParseIntPipe) id: number, @Request() req, @Body('reason') reason: string) {
    return this.svc.cancel(id, req.user.id, reason);
  }
}
