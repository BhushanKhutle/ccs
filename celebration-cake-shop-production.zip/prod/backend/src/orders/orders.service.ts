import { Injectable, NotFoundException, BadRequestException, ForbiddenException, Logger } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Order, OrderStatus } from './order.entity';

@Injectable()
export class OrdersService {
  private readonly logger = new Logger(OrdersService.name);

  constructor(@InjectRepository(Order) private repo: Repository<Order>) {}

  async create(userId: number, data: any): Promise<Order> {
    if (!data.items?.length) throw new BadRequestException('Order must have at least one item');

    const orderNumber = `CCS-${Date.now()}`;
    const otp = Math.floor(1000 + Math.random() * 9000).toString();

    const order = this.repo.create({
      orderNumber,
      userId,
      items: data.items,
      address: data.address,
      subtotal: +data.subtotal,
      discount: +(data.discount || 0),
      deliveryCharge: +(data.deliveryCharge || 0),
      total: +data.total,
      couponCode: data.couponCode || null,
      paymentMethod: data.paymentMethod,
      deliverySlot: data.deliverySlot,
      deliveryDate: data.deliveryDate,
      message: data.message,
      otp,
      statusHistory: [{ status: OrderStatus.PLACED, timestamp: new Date(), note: 'Order placed by customer' }],
    });

    const saved = await this.repo.save(order);
    this.logger.log(`Order created: ${saved.orderNumber} by user ${userId}`);
    return saved;
  }

  findByUser(userId: number, page=1, limit=10) {
    return this.repo.findAndCount({
      where: { userId },
      order: { createdAt: 'DESC' },
      skip: (+page-1)*+limit, take: +limit,
    });
  }

  findAll(page=1, limit=20, status?: OrderStatus) {
    const where: any = {};
    if (status) where.status = status;
    return this.repo.findAndCount({
      where,
      order: { createdAt: 'DESC' },
      skip: (+page-1)*+limit, take: +limit,
    });
  }

  async findOne(id: number): Promise<Order> {
    const o = await this.repo.findOne({ where: { id }, relations: ['user'] });
    if (!o) throw new NotFoundException(`Order #${id} not found`);
    return o;
  }

  async findByNumber(orderNumber: string): Promise<Order> {
    const o = await this.repo.findOne({ where: { orderNumber } });
    if (!o) throw new NotFoundException(`Order ${orderNumber} not found`);
    return o;
  }

  async updateStatus(id: number, status: OrderStatus, note?: string): Promise<Order> {
    const order = await this.findOne(id);
    const history = order.statusHistory || [];
    history.push({ status, timestamp: new Date(), note: note || `Status updated to ${status}` });
    await this.repo.update(id, { status, statusHistory: history });
    this.logger.log(`Order ${order.orderNumber} status → ${status}`);
    return this.findOne(id);
  }

  async cancel(id: number, userId: number, reason: string): Promise<Order> {
    const order = await this.findOne(id);
    if (order.userId !== userId) throw new ForbiddenException('Not your order');
    if ([OrderStatus.DELIVERED, OrderStatus.CANCELLED].includes(order.status)) {
      throw new BadRequestException('This order cannot be cancelled');
    }
    return this.updateStatus(id, OrderStatus.CANCELLED, reason || 'Cancelled by customer');
  }

  getStats() {
    return this.repo.query(`
      SELECT
        COUNT(*) as total_orders,
        SUM(total) as total_revenue,
        COUNT(CASE WHEN status = 'delivered' THEN 1 END) as delivered,
        COUNT(CASE WHEN status = 'placed' THEN 1 END) as placed,
        COUNT(CASE WHEN status = 'preparing' THEN 1 END) as preparing,
        COUNT(CASE WHEN status = 'out_for_delivery' THEN 1 END) as out_for_delivery,
        COUNT(CASE WHEN status = 'cancelled' THEN 1 END) as cancelled,
        AVG(total) as avg_order_value
      FROM orders
    `);
  }
}
