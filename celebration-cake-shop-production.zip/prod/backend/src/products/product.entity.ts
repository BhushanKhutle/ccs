import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, UpdateDateColumn, Index } from 'typeorm';

export enum ProductStatus { ACTIVE = 'active', INACTIVE = 'inactive', OUT_OF_STOCK = 'out_of_stock' }

@Entity('products')
export class Product {
  @PrimaryGeneratedColumn()
  id: number;

  @Index()
  @Column()
  name: string;

  @Column({ type: 'text', nullable: true })
  description: string;

  @Column({ type: 'decimal', precision: 10, scale: 2 })
  price: number;

  @Column({ type: 'decimal', precision: 10, scale: 2, nullable: true })
  oldPrice: number;

  @Index()
  @Column({ nullable: true })
  category: string;

  @Index()
  @Column({ nullable: true })
  occasion: string;

  @Column({ nullable: true })
  flavour: string;

  @Column({ nullable: true })
  emoji: string;

  @Column({ nullable: true })
  imageUrl: string;

  @Column({ nullable: true })
  weights: string;

  @Column({ nullable: true })
  flavours: string;

  @Column({ default: true })
  eggless: boolean;

  @Column({ default: true })
  isActive: boolean;

  @Column({ default: 0 })
  stock: number;

  @Column({ type: 'decimal', precision: 3, scale: 2, default: 0 })
  rating: number;

  @Column({ default: 0 })
  reviewCount: number;

  @Column({ nullable: true })
  tag: string;

  @Column({ type: 'enum', enum: ProductStatus, default: ProductStatus.ACTIVE })
  status: ProductStatus;

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;
}
