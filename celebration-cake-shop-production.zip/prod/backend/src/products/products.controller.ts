import { Controller, Get, Post, Put, Delete, Body, Param, ParseIntPipe, Query, UseGuards } from '@nestjs/common';
import { ApiTags, ApiOperation, ApiBearerAuth, ApiQuery } from '@nestjs/swagger';
import { ProductsService } from './products.service';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';

@ApiTags('Products')
@Controller('api/v1/products')
export class ProductsController {
  constructor(private readonly svc: ProductsService) {}

  @Get()
  @ApiOperation({ summary: 'Get all products with filters and pagination' })
  @ApiQuery({ name: 'category', required: false })
  @ApiQuery({ name: 'occasion', required: false })
  @ApiQuery({ name: 'eggless', required: false })
  @ApiQuery({ name: 'tag', required: false })
  @ApiQuery({ name: 'page', required: false })
  @ApiQuery({ name: 'limit', required: false })
  @ApiQuery({ name: 'sort', required: false, description: 'e.g. rating:DESC' })
  findAll(@Query() query: any) { return this.svc.findAll(query); }

  @Get('bestsellers')
  @ApiOperation({ summary: 'Get bestseller products' })
  getBestsellers(@Query('limit') limit=12) { return this.svc.getBestsellers(+limit); }

  @Get('featured')
  @ApiOperation({ summary: 'Get featured products' })
  getFeatured(@Query('limit') limit=8) { return this.svc.getFeatured(+limit); }

  @Get('search')
  @ApiOperation({ summary: 'Search products' })
  @ApiQuery({ name: 'q', required: true })
  search(@Query('q') q: string, @Query('page') page=1, @Query('limit') limit=20) {
    if (!q?.trim()) return { items: [], total: 0 };
    return this.svc.search(q, +page, +limit);
  }

  @Get(':id')
  @ApiOperation({ summary: 'Get product by ID' })
  findOne(@Param('id', ParseIntPipe) id: number) { return this.svc.findOne(id); }

  @Post()
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth('JWT')
  @ApiOperation({ summary: 'Create product (admin)' })
  create(@Body() body: any) { return this.svc.create(body); }

  @Put(':id')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth('JWT')
  @ApiOperation({ summary: 'Update product (admin)' })
  update(@Param('id', ParseIntPipe) id: number, @Body() body: any) { return this.svc.update(id, body); }

  @Delete(':id')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth('JWT')
  @ApiOperation({ summary: 'Soft-delete product (admin)' })
  remove(@Param('id', ParseIntPipe) id: number) { return this.svc.remove(id); }
}
