import { Controller, Get, Patch, Body, Param, ParseIntPipe, UseGuards, Request, Query } from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation, ApiQuery } from '@nestjs/swagger';
import { UsersService } from './users.service';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';

@ApiTags('Users')
@ApiBearerAuth('JWT')
@UseGuards(JwtAuthGuard)
@Controller('api/v1/users')
export class UsersController {
  constructor(private readonly svc: UsersService) {}

  @Get()
  @ApiOperation({ summary: 'List all users (admin)' })
  @ApiQuery({ name: 'page', required: false })
  @ApiQuery({ name: 'limit', required: false })
  findAll(@Query('page') page=1, @Query('limit') limit=20) {
    return this.svc.findAll(+page, +limit);
  }

  @Get('profile')
  @ApiOperation({ summary: 'Get my profile' })
  getProfile(@Request() req) { return this.svc.findOne(req.user.id); }

  @Patch('profile')
  @ApiOperation({ summary: 'Update my profile' })
  updateProfile(@Request() req, @Body() body: Partial<any>) {
    const { password, role, ...safe } = body;
    return this.svc.update(req.user.id, safe);
  }
}
