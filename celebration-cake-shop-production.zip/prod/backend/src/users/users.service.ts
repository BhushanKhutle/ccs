import { Injectable, NotFoundException, ForbiddenException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { User, UserRole } from './user.entity';

@Injectable()
export class UsersService {
  constructor(@InjectRepository(User) private repo: Repository<User>) {}

  findAll(page=1, limit=20) {
    return this.repo.findAndCount({
      order: { createdAt: 'DESC' },
      skip: (page-1)*limit, take: limit,
      select: ['id','name','email','mobile','role','isActive','walletBalance','createdAt'],
    });
  }

  async findOne(id: number): Promise<User> {
    const user = await this.repo.findOne({ where: { id } });
    if (!user) throw new NotFoundException(`User #${id} not found`);
    return user;
  }

  async findByEmail(email: string): Promise<User> {
    return this.repo.findOne({ where: { email }, select: ['id','name','email','mobile','role','isActive','password','walletBalance'] });
  }

  async update(id: number, data: Partial<User>): Promise<User> {
    const user = await this.findOne(id);
    Object.assign(user, data);
    return this.repo.save(user);
  }

  async deactivate(id: number): Promise<User> {
    return this.update(id, { isActive: false });
  }
}
